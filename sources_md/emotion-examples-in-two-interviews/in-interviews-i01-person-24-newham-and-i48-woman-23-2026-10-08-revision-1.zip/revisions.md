# Revisions

- 8 October 2026: asked to refer to the interviewee of I01 as a person, using they/them. Presentation only: wording changed in the answer, in the question as agreed, in four row labels (subject column, free text) and in the audit notes; no definition, value, quotation or row changed, row ids unchanged; recounted with the answer, all counts as before.
