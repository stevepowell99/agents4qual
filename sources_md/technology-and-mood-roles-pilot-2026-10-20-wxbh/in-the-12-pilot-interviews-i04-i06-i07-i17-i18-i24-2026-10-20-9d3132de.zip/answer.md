# Technology and young people's moods

## The answer

Across the {t_role.of} interviews, the young people describe the following roles that technology plays in their own moods, counted by person.

Lifting or easing mood:

- Keeping in touch with particular people by call, message, social media or a shared series ({t_role[Keeping in touch]}; without prompting, {t_role_unprompted[Keeping in touch]}).
- Entertainment and distraction: YouTube, Netflix, phone and telly, console games, funny posts and music ({t_role[Entertainment]}).
- Contact on their own terms, choosing when to talk or to log off ({t_role[On my own terms]}).
- Comfort when lonely or low, mostly from music ({t_role[Comfort]}).
- Recognition from posting and motivation from pictures ({t_role[Recognition and motivation]}, I06).

Lowering mood:

- Comparing themselves with others' lives, looks or luxury on screen ({t_role[Comparison]}).
- Screens that fail to fill empty time or leave them still alone ({t_role[Empty filler]}).
- Fear of judgement keeping them off social media, or technology as the means of withdrawing ({t_role[Hiding]}).
- Seeing in posts that they were left out ({t_role[Left out]}).
- Messages and calls that let them down ({t_role[Let down by messages]}).
- Phones and games coming between them and the people they are with ({t_role[Screens between people]}).
- Dismay at social media's fakery ({t_role[Fakery]}).
- Being cut off without a phone ({t_role[Cut off without a phone]}, I24).

Most describe technology on both sides of their mood: {t_sides[yes,yes]} people tie it to a feeling of their own that it lifts and to one that it lowers. {t_sides[yes,no]} people (I29) describe it only lifting their mood, {t_sides[no,yes]} (I48) only lowering it, and {t_sides[no,no]} (I18) never tie it to a feeling of their own.

Two patterns run through these roles. Contact with a particular person through a screen is told mostly as easing loneliness, though I04 and I42 describe messages and calls that hurt, while watching or playing alone is told both ways, as failing to fill the gap and as filling time or lifting mood [k.connect]. Most of the negative accounts of social media are about the measure it holds up: others' better lives, and events the speaker was left out of; the others are fear of being judged (I28), dismay at its fakery (I04, I42) and browsing that brings mood down (I43) [k.measure].

{{figure t_role}}

## What lifts mood

{t_any[positive]} people describe technology lifting or easing their mood. Keeping in touch is the role raised most often without prompting ({t_role_unprompted[Keeping in touch]}). A call makes being alone in their apartment less bad for one interviewee, though it is still the loneliest place: "it’s not as bad as living in Essex, because even when I’m in my apartment I have some things to do, like whether I’m on the phone with a friend" (I28) [c_tech.3dcpm]. In their first year at university, on a doctor's advice, the same interviewee called home, and "it did help a little bit, not too much" (I28) [c_tech.pqsee]. Another recalls friends from university and sixth form who "lit you up when you felt so down or lonely, just a phone call away" (I29) [c_tech.3n8mk], and adds that "since I started working, you know, it’s not the same as before" (I29). Others call or message someone when bored of their own company (I24) [c_tech.tbptm], know that they "could call one of my friends" (I17) [c_tech.kjz6g], or had family texts checking on them during exams (I07) [c_tech.9hkqq].

Entertainment is mostly screens used alone: one interviewee likes "going on YouTube and just watching stuff that I never think to learn" (I42) [c_tech.nrd49], and another likes to "sit there and go on my phone and watch telly" (I17) [c_tech.b55qw]. Comfort is narrower: turning to music when lonely or low, to share and understand the feeling, in I06 [c_tech.mp9j5, c_tech.fna5f], and to motivational YouTube videos, "whatever helps", in I28, in answer to a question that raised social media [c_tech.rjhaw].

For contact on their own terms ({t_role[On my own terms]}), the value is control. One interviewee says "being in bed with my phone it's like I can be myself and still be accepted" and "I can just log off, you know. When you're with people you cannot just walk away." (I37) [c_tech.uzqwt, c_tech.gy89c]. Another is "quite careful with how I manage my social media, who I follow, who I talk to, so it's not an unpleasant feeling when I'm on social media, it's normally good" (I07) [c_tech.b6x8c]. Recognition from posting Snapchat stories, and motivation from gym pictures, appear only in I06 [c_tech.2vgxx, c_tech.3jw6p]; the same interviewee's second thoughts about posting are under Outside the frame.

## What lowers mood

{t_any[negative]} people describe technology starting, keeping going or worsening a bad feeling of their own. Comparison ({t_role[Comparison]}) is mostly about social media. Seeing others "all happy" on social media when already sad and lonely makes one interviewee feel worse: "Not worse, but it does a little bit" (I17) [c_tech.2wf3s]. Another feels that people on Instagram are better: "I just almighty feel like they're better than me" (I07) [c_tech.zpvab]. A third "sometimes does get a bit jealousy" at luxury lives on Instagram and Facebook, and at once discounts it (I43) [c_tech.c2js6]. Outside social media, one penalises themselves each morning for not looking like "the models on TV" (I37) [c_tech.vwvjb].

Seeing that they were left out is close to comparison but about a particular event: photos of outings, when "you start feeling alone" (I06) [c_tech.vqggw], or learning, on Facebook as far as they remember, that friends went out without them (I42) [c_tech.axsy8].

Empty filler is the commonest negative role outside social media: "Sometimes, TV can be boring to watch, so you just turn it off" (I48) [c_tech.95yja]. Of their first year at university, another says of watching YouTube alone: "But at the end of the day, you know, I’m still alone." (I28) [c_tech.prvtc].

Fear of judgement and withdrawal keep loneliness going ({t_role[Hiding]}). One interviewee keeps off Snapchat and Instagram for fear of being judged, which leaves them "forced to sort of keep myself to myself" (I28) [c_tech.knspn, c_tech.g92z2], and "that kind of sort of made me feel more lonely" (I28). Another texts excuses to stay in bed because "you’re scared of their opinion" (I37) [c_tech.kfcku]. A third used to doubt whether people would like their true self behind the character they had built on social media (I42) [c_tech.aneea].

Messages and calls let people down: the phone going off after a breakup and not being the ex (I04) [c_tech.dzaah]; "looking at your phone, waiting for an invitation" that "just doesn't come through" (I42) [c_tech.eutdt], which the same interviewee then qualifies (see Outside the frame); and friends lying by message, and check-up calls that "kinda of got depressing" (I42) [c_tech.bgxg4, c_tech.m2ek2].

Phones and games come between people in company: with everyone on their phones at a meal, "it kind of takes that connection away" (I43) [c_tech.tqnaa], and with friends playing FIFA, a game the interviewee dislikes, "you kind of have to disconnect with people" (I42) [c_tech.vnpt7]. Dismay at social media's fakery is "one of despair because it’s not gonna change" (I42) [c_tech.4798p]. Being without a phone makes one interviewee "feel so lost" (I24) [c_tech.zqpnq]. One passage fits none of these roles: reading online about their symptoms "was just scaring me like all the time" (I28) [c_tech.vv5g4].

## Alone or with someone

In I43, watching a Netflix series "no one watches" leaves "no one to talk to", while finding "the person that watches the same series" means "it kind of fills that loneliness" [c_tech.hmakb, c_tech.rhah4]. Screens used alone leave people still alone or bored in I17, I28, I43 and I48 [c_tech.we6xs, c_tech.prvtc, c_tech.hmakb, c_tech.hfnc9], but fill time or lift mood in I17, I28 and I42 [c_tech.b55qw, c_tech.3dcpm-2, c_tech.6zndd]; I28 tells both, YouTube alone in their first year and Netflix on the laptop in their apartment now. In I37 the control a phone gives over contact is both a relief and the means of the excuses that keep them in bed [k.control] [c_tech.gy89c, c_tech.kfcku]; being without a phone, by contrast, is told as loss (I24) [c_tech.r68g3].

## By kind of technology

Social media is tied to negative feelings by {t_medium[social_media,negative]} people and to positive ones by {t_medium[social_media,positive]}. Messaging and calls run the other way: {t_medium[messaging_calls,positive]} positive against {t_medium[messaging_calls,negative]} negative. Gaming and streaming fall on both sides ({t_medium[gaming_streaming,positive]} positive, {t_medium[gaming_streaming,negative]} negative). No passage was told as helping and harming at once in a way that could not be split ({t_any[mixed]}).

{{figure t_medium}}

## Outside the frame

Some of the strongest views about technology in these interviews are about other people, not the speaker's own mood, and so were not counted: {t_off[general_view]} people give such general views. One links social media comparison to loneliness among young people in general: "that leads them to be lonely" (I29) [c_off.bp2vq]; another sees social media as "just like drugs" for some people (I04) [c_off.rtgtd].

There are doubts inside some accounts ({t_off[doubt]}). Asked how they feel about people on social media showing a different image from what they feel inside, one interviewee says "I don’t really feel anything about it" (I17) [c_off.v3e9u], shortly after saying such posts make them feel "a little bit" worse [c_tech.2wf3s]; of sitting in front of the telly for hours, the same interviewee says "I don’t do it personally" [c_off.2dz24]. Of their own Snapchat posts, another reflects that "I could just enjoy their own company" (I06), and that "I felt the need to um for others to see and compare themselves with to make myself feel better" [c_off.jmshw]. Straight after describing waiting by the phone for an invitation, another says that as an introvert "it’s a lot harder for me to kind of feel loneliness" (I42) [c_off.kv4b7]. One says that seeing what others have is "never a negative feeling", before describing Instagram making them feel not good enough (I07) [c_off.cgzbv]. One, asked how being left out without a phone makes them feel, names doubting whether anyone likes them and then says "But not in this case" (I24) [c_off.ucu7e]. And one gives friends a cover story for not being on social media (I28) [c_off.xdee3].

Some interviewees reject or reframe the interviewer's suggestion ({t_off[rejected_suggestion]}). Asked whether friends gaming left them feeling left out, one says "it wasn’t more a feeling left out" (I42) [c_off.f23zg]; another says that going round in circles at home is "not just a phone situation" (I17) [c_off.c2nrq]. One describes chatting on their phone as "a massive time-waster" that kept them up late, with no feeling attached (I04) [c_off.2uejw], the one effect of this kind ({t_off[other_effect]}).

## Limitations

This is a pilot of {t_role.of} interviews, so most roles rest on a few people, and several on one person. The interviews were about loneliness, not technology, and interviewers sometimes raised social media themselves: Comparison drops from {t_role[Comparison]} to {t_role_unprompted[Comparison]} people when prompted accounts are set aside, and Fakery from {t_role[Fakery]} to {t_role_unprompted[Fakery]}. Each row records what a speaker says technology does to their own mood: a store of evidence about how it works, not a model of it (Powell, Copestake and Remnant 2024), and no measure of how much it does. One coder placed every passage, and a single reader checked the answer.

- Entertainment and Keeping in touch as the joint commonest positive roles ({t_role[Entertainment]} each) rest on counting music where no device is named (I06, I24) as technology; read the other way, Entertainment falls below Keeping in touch, which becomes the single commonest role, and Comfort rests on I28 alone.
- That I29 is the one person for whom technology only lifts mood ({t_sides[yes,no]}) rests on not reading as a role their remark that since starting work "Whenever you message your friends, they’re busy, they can’t reply back", which they follow, when asked, with "It’s really sad" (I29); read as a negative role, nobody describes technology only lifting their mood.
- Comparison's unprompted count ({t_role_unprompted[Comparison]}) rests on how follow-up questions are marked: I17's account is marked unprompted because they raised social media first, though the interviewer's question named it, while I07's answers to questions about social media, which they had written on their sheet, are marked prompted; marked alike either way, the unprompted count would move by one person, down or up.
